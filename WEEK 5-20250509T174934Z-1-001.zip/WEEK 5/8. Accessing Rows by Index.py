# Access the row at index 1 (second row)
second_row = df.iloc[1]
print(second_row)
