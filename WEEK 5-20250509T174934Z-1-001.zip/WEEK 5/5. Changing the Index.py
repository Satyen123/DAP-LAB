# Set 'Age' as the new index
df_with_new_index = df.set_index('Age')
print(df_with_new_index)
