# Set 'Name' column as the index
df_with_index = df.set_index('Name')
print(df_with_index)
