# Access the 'Age' column
age_column = df['Age']
print(age_column)
