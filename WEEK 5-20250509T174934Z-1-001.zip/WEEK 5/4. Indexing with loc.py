row = df.loc[1]  # This will actually throw an error because 'loc' works with labels, not numerical indices.
print(row)
