# Reset the index back to the default integer index
df_reset = df.reset_index()
print(df_reset)
