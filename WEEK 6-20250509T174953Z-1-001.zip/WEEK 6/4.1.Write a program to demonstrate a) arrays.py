import numpy as np
a = np.array(42)
b = np.array([1, 2, 3, 4, 5])
c = np.array([[1, 2, 3], [4, 5, 6]])
d = np.array([[[1, 2, 3], [4, 5, 6]], [[1, 2, 3], [4, 5, 6]]])
print("entered array is:",a,"and its dimension is:",a.ndim)
print("entered array is:",b,"and its dimension is:",b.ndim)
print("entered array is:",c,"and its dimension is:",c.ndim)
print("entered array is:",d,"and its dimension is:",d.ndim) 