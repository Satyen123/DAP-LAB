import numpy as np
a= np.array([[1,23,78],[98,60,75],[79,25,48]])
print("Entered array=",a)
#Minimum Function
print("minimum=",np.amin(a))
#Maximum Function
print("maximum=",np.amax(a))
#Mean Function
print("mean=",np.mean(a))
#Median Function
print("median=",np.median(a))
#std Function
print("standarad deviation=",np.std(a))
#var Function
print("variance=",np.var(a))