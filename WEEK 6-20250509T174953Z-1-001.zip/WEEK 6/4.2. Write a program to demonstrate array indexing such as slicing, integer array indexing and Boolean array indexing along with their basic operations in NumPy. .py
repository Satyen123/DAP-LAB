import numpy as np
a=np.arange(10,1,-2)
print("a sequential array with nagative step value:",a)
newarr=[a[3],a[1],a[2]]
print("elements at these indices are:",newarr)
a=np.arange(20)
print("Array is:",a)
print("a[-8:17:1]=",a[-8:17:1])
print("a[10:]=",a[10:]) 