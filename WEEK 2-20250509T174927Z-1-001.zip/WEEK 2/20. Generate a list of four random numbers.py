import random

random_numbers = [random.randint(1, 100) for _ in range(4)] 
print("Random numbers:", random_numbers)
